package com.najwah.login_app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.najwah.login_app.MainActivity
import com.kuispemro2.loginapp.R
import org.json.JSONObject

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val email = findViewById<EditText>(R.id.etEmail)
        val password = findViewById<EditText>(R.id.etPassword)
        val login = findViewById<Button>(R.id.btnLogin)
        val register = findViewById<Button>(R.id.btnRegister)

        login.setOnClickListener {
            val e = email.text.toString().toString()
            val p = password.text.toString()

            if (e.isEmpty() || p.isEmpty()) {
                Toast.makeText(
                    this, "Email dan password wajib diisi",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            login.isEnabled = false

            Thread {
                try {
                    val data = JSONObject()
                    data.put("email", e)
                    data.put("password", p)

                    val result = ApiClient.post("login.php", data)

                    runOnUiThread {
                        login.isEnabled = true

                        if (result.optBoolean("success")) {
                            val user = result.optJSONObject("data")
                            val intent = Intent(
                                this, DashboardActivity::class.java
                            )
                            intent.putExtra(
                                "nama", user?.optString("nama", "") ?: ""
                            )
                            intent.putExtra(
                                "email", user?.optString("email", "") ?: ""
                            )
                            startActivity(intent)
                            finish()
                        } else {
                            Toast.makeText(
                                this,
                                result.optString(
                                    "message", "Login gagal"
                                ),
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                } catch (ex: Exception) {
                    runOnUiThread {
                        login.isEnabled = true
                        Toast.makeText(
                            this,
                            "Gagal terhubung ke server: ${ex.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }.start()
        }

        register.setOnClickListener {
            startActivity(
                Intent(this, RegisterActivity::class.java)
            )
        }
    }
}
