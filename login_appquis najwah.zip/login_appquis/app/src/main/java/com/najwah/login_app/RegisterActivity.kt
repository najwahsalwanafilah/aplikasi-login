package com.najwah.login_app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.najwah.login_app.RegisterActivity
import com.kuispemro2.loginapp.R
import org.json.JSONObject

class RegisterActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val Nama = findViewById<EditText>(R.id.etNama)
        val email = findViewById<EditText>(R.id.etEmail)
        val password = findViewById<EditText>(R.id.etPassword)
        val konfirmasi = findViewById<EditText>(
            R.id.etConfirmPassword
        )
        val nama = findViewById<EditText>(R.id.etNama)
        val daftar = findViewById<Button>(R.id.btnDaftar)
        val kembali = findViewById<Button>(R.id.btnKembali)


        daftar.setOnClickListener {
            val n = nama.text.toString().toString()
            val e = email.text.toString().toString()
            val p = password.text.toString()
            val cp = konfirmasi.text.toString()

            if (n.isEmpty() || e.isEmpty() || p.isEmpty() || cp.isEmpty()) {
                Toast.makeText(
                    this, "Semua kolom wajib diisi",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            if (p != cp) {
                Toast.makeText(
                    this, "Konfirmasi password tidak sama",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            if (p.length < 8) {
                Toast.makeText(
                    this, "Password minimal 8 karakter",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            daftar.isEnabled = false

            Thread {
                try {
                    val data = JSONObject()
                    data.put("nama", n)
                    data.put("email", e)
                    data.put("password", p)

                    val result = ApiClient.post("register.php", data)

                    runOnUiThread {
                        daftar.isEnabled = true

                        Toast.makeText(
                            this,
                            result.optString("message"),
                            Toast.LENGTH_LONG
                        ).show()

                        if (result.optBoolean("success")) {
                            startActivity(
                                Intent(this, MainActivity::class.java)
                            )
                            finish()
                        }
                    }
                } catch (ex: Exception) {
                    runOnUiThread {
                        daftar.isEnabled = true
                        Toast.makeText(
                            this,
                            "Gagal terhubung ke server: ${ex.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }.start()
        }

        kembali.setOnClickListener {
            finish()
        }
    }
}
