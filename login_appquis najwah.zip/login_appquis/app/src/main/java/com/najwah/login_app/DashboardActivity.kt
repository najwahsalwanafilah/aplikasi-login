package com.najwah.login_app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.najwah.login_app.DashboardActivity
import com.najwah.login_app.ApiClient
import com.najwah.login_app.MainActivity
import com.najwah.login_app.RegisterActivity
import com.kuispemro2.loginapp.R

class DashboardActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val nama = intent.getStringExtra("nama") ?: "Pengguna"
        val email = intent.getStringExtra("email") ?: ""

        findViewById<TextView>(R.id.tvWelcome).text =
            "Selamat datang, najwah!"

        findViewById<TextView>(R.id.tvEmail).text = email

        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags =
                Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}
