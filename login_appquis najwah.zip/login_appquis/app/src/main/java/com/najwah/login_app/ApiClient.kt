package com.najwah.login_app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ApiClient {
    private const val BASE_URL =
        "http://10.0.2.2/login_api/"

    fun post(
        endpoint: String,
        data: JSONObject
    ): JSONObject {
        val connection = URL(BASE_URL + endpoint)
            .openConnection() as HttpURLConnection

        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 10000
            connection.readTimeout = 10000
            connection.doOutput = true
            connection.setRequestProperty(
                "Content-Type",
                "application/json; charset=UTF-8"
            )

            connection.outputStream.use {
                it.write(data.toString().toByteArray(Charsets.UTF_8))
            }

            val status = connection.responseCode
            val stream = if (status in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            }

            val body = stream.bufferedReader().use {
                it.readText()
            }

            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }
}


